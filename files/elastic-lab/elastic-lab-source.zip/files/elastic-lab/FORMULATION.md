# Elastic Stress Effects Laboratory: formulation before implementation

## Scope and conventions
This release studies prescribed eigenstrains and fixed shapes, not time-evolving morphology. x=[10], y=[01]. All directions on the page have two indices. Strains are symmetric tensors; the third stored component is tensor shear epsilon_xy, not engineering shear. The 2-D constitutive law is sigma_xx=C11 e_xx+C12 e_yy, sigma_yy=C12 e_xx+C11 e_yy, sigma_xy=2 C44 e_xy. It is an in-plane model using the cubic (001) stiffness sub-block, with no imposed out-of-plane eigenstrain. It is not a plane-stress reduction of a fully 3-D dilatational transformation. Stable cubic inputs obey C44>0, C11-C12>0, C11+2 C12>0.

Module I: n(theta) is an arbitrary measurement direction. epsilon_nn/epsilon_eta=cos²(theta)+t sin²(theta). At a root that measurement direction becomes the habit-line tangent s. Its normal m is rotated 90 degrees. For t<0, theta=atan2(1,sqrt(-t)) and pi-theta. At t=0 theta=pi/2. For t>0 no roots. For t=-1 roots are 45 and 135 degrees. The acute interface-normal angle is atan(sqrt(-t)). Eq 4.10 of Saswata's thesis labels the latter as a line angle from x; the tool states the discrepancy explicitly rather than silently swapping axes.

A zero tangential strain permits a rank-one displacement-gradient jump in the 2-D small-strain setting: epsilon0=sym(a tensor m), after allowing a rigid rotation. This is the compatibility argument for an ideal infinite thin plate, not an assertion that every zero normal-strain direction has zero total elastic energy. Finite plates and interfaces add constraints and costs.

## Module II: Eshelby's elliptical inclusion and jump conditions
Homogeneous stiffness C (in-plane cubic law, plane strain), eigenstrain epsilon0 uniform inside an ellipse with semi-axes a (long axis at angle phi from [10]) and b. With Q_ik(n)=C_ijkl n_j n_l, sigma0=C:epsilon0 and g(n)=Q(n)^-1 sigma0 n, the interior displacement gradient is D=(1/2pi) int_0^2pi g(n) (x) n dtheta with n parallel to R(phi)(cos theta/a, sin theta/b) (Mura, Micromechanics of Defects in Solids, section 11). Interior strain eps_c=sym D (=S:epsilon0), rotation omega=(D_yx-D_xy)/2, stress sigma_in=C:(eps_c-epsilon0), energy per unit inclusion area w=-sigma_in:epsilon0/2. Midpoint rule, 4096 samples (2048 in sweeps); b/a >= 0.01.

At a boundary point with outward normal m: eps_out=eps_c-sym(g(m) (x) m), sigma_out=C:eps_out. Hence [[eps_ss]]=0 and [[sigma]]m=0 exactly; eps_sm, eps_mm and sigma_ss jump, and the jump depends only on m, epsilon0 and C. Thin-plate limit b/a->0: D->g(m0) (x) m0 and w->B(m0)/2. Checks: the integral reproduces Mura's isotropic plane-strain elliptic-cylinder Eshelby tensor to machine precision; thin plate at b/a=0.002 matches B/2; interface conditions hold to 1e-17.

Field maps: periodic unit cell, 256^2, a=0.16, 4x4 supersampled indicator theta, eps_hat(k)=sym(g(k^) (x) k^) theta_hat(k) for k!=0 (Nyquist modes dropped), mean total strain zero, sigma=C:(eps-theta epsilon0). Periodic images and the area fraction shift interior values by a few per cent from the infinite-matrix values; b/a is clamped to >= 0.08 for the maps.

## Homogeneous kernel: Appendix A
Primary derivation: Saswata’s Appendix A, Eqs. A.1–A.12, pp. 107–111. The elastic driving force follows Appendix B, Eqs. B.1–B.12, pp. 112–114, with the selected field index kept free. See SOURCE-AUDIT.md for the derivation and notation checks.

sigma0_p=C:epsilon0_p; Q_ik=C_ijkl n_j n_l; a_p=sigma0_p n.
B_pq=epsilon0_p:C:epsilon0_q-a_p dot Q^-1 a_q.
Compute each p,q independently. B_pq=B_qp; the matrix is positive semidefinite, but cross entries can be negative. A sign change epsilon0_q -> -epsilon0_q flips B_pq and leaves B_qq unchanged.

Reference: Sandeep Sugathan thesis, Eqs 3.22 and 3.27-29, Eq 5.1, Tables 5.1-5.2 pp116, Fig5.18 pp133, discussion pp132. G=2000, nu=1/3, AZ=3 gives C11=7000,C12=5000,C44=3000. X2: beta=.01 I, gamma=-.01 I. X3: beta=.01265 I, gamma=-.00632 I. The numerical reproduction gives self values 12/35 on the axes and 0.8 on diagonals, with cross values of the opposite sign. These match Fig. 5.18. This verifies the stated 2-D convention; it does not reproduce the full evolving ternary microstructure.

## Pair energy
Use identical smooth circular Gaussian composition profiles in a periodic square. Evaluate E_int=E(beta+gamma)-E(beta)-E(gamma) via the Fourier bilinear cross term including cos(k dot R). This sum includes shape spectrum and separation; it is not B evaluated at the separation angle. Report box size, radius and distance. Periodic copies remain part of the calculation. Positive E_int is a cost relative to isolated profiles in the same periodic box. Negative E_int is a reduction. No claim of isolated infinite-medium interactions.

## Inhomogeneous plate solver
Reference equilibrium: the CICP paper (2012), Eqs. 2.6–2.16; associated phase-field driving force: Tushar Jogi’s thesis, Appendix B. The browser solves these equilibrium equations using PCG, separately checked against a CICP-style spectral fixed-point iteration. SOURCE-AUDIT.md records the Green-tensor wave-number factor, mean-stiffness inverse, and exact indicial contractions.

Prescribe one smooth elliptic plate in a periodic unit square, with a fixed volume fraction and crystal-frame eigenstrain. Interpolate C(x)=(1-h)Cm+hCp and epsilon0(x)=h epsilon_p. Minimize F=mean[epsilon_el:C(x):epsilon_el]/2 over periodic displacement u, at fixed mean total strain zero. This is a clamped macroscopic boundary condition, not zero average stress. Rotate the shape, not the crystal axes or eigenstrain.

Use spectral symmetric gradients and their exact discrete adjoints, then preconditioned conjugate gradients for A u=b, A=D* C(x) D, b=D* C(x) epsilon0. The homogeneous reference modulus acoustic inverse preconditions the solve. The mean displacement is fixed to zero. Real spectral derivatives set Nyquist derivatives to zero on even grids; their null modes are excluded from displacement and retained in unrelaxed eigenstrain energy. Smooth masks and grid convergence control their contribution. Never use a single homogeneous B for nonuniform C.

Reference energy for homogeneous C is evaluated independently in Fourier space by eliminating displacement mode by mode, including the k=0 clamped term. Validate the real-space solver against this reference. Report relative residual, iteration limit, energy and convergence; reject failed solves in orientation scans. A finite sampled minimum is not a proof of a global continuum optimum. Compare 32/64/128 grids and 5/2.5 degree angle steps; expose this limitation.

## Sharp interfaces, diffuse profiles and interpolation
For a sharp coherent inclusion, epsilon0=chi_Omega epsilonT and C=Cm+chi_Omega(Cp-Cm). Mura's interface conditions are continuity of displacement and traction, [u]=0 and [sigma]n=0, with the displacement-gradient jump in Hadamard form [grad u]=a tensor n. A spatial tanh profile h(d)=[1-tanh(d/w)]/2 regularizes the indicator over a prescribed width; it is not itself a choice of phase-field interpolation h(eta).

For a physical composition or phase fraction, begin with linear interpolation. For an evolving 0-to-1 structural phase field, the teaching default is the cubic smoothstep h=eta^2(3-2 eta), whose first derivative vanishes in both pure phases. The quintic h=eta^3(10-15 eta+6 eta^2) is provided as a comparison whose first and second derivatives vanish at the endpoints. eta^2 is retained only when positive and negative order-parameter amplitudes represent the same eigenstrain contribution. If C and epsilon0 depend on eta, the elastic derivative contains both 1/2 epsilon_el:C_,eta:epsilon_el and -sigma:epsilon0_,eta.

## Homogeneous strain and macroscopic loading
Write u=Ebar x+u_tilde, where u_tilde is periodic. Then epsilon=Ebar+epsilon_tilde, mean(epsilon_tilde)=0, and the k=0 strain is V Ebar under the stated transform convention. The Green operator solves the nonzero modes. The macroscopic boundary condition fixes the zero mode.

Under strain control, prescribe Ebar, equilibrate the fluctuations and calculate Sigma=mean(sigma). Under stress control, prescribe Sigma and solve for Ebar; never impose the same stress at every voxel. For fixed linear elasticity, Sigma=Ceff:Ebar+Sigma0, so Ebar=inv(Ceff):(Sigma_target-Sigma0). Mixed control partitions the zero-mode components into prescribed strains and prescribed average stresses.

For a film-substrate slab separated from its periodic images by soft vacuum, equilibrium and negligible vacuum stress make the exposed solid traction approximately zero. Exact zero vacuum stiffness leaves vacuum displacement modes undetermined. Check vacuum stiffness, vacuum thickness and spatial resolution. In-plane stress should be reported as a solid-volume average or membrane resultant, not diluted by arbitrary vacuum volume. Nonzero surface pressure requires an explicit traction or an equivalent loading method.

## Sources and licensing
Saswata Bhattacharyya thesis: Chapter3 Eq3.2 and Chapter4 Eq4.10, Fig4.4. Sandeep Sugathan: A Phase-Field Study of Elastic Stress Effects on Phase Separation in Ternary Alloy Systems, IIT Hyderabad, June 2019, Chapters 3 and 5 above. Existing website elastic appendix supplies the homogeneous derivation. New laboratory code: GPL-3.0-or-later. Existing website template remains MIT; thesis figures retain their authors' rights. Do not redistribute full theses.

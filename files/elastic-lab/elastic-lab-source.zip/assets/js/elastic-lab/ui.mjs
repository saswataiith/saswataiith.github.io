// SPDX-License-Identifier: GPL-3.0-or-later
import {
  contract,
  stress,
  mohrState,
  radians,
  roots,
  projection,
  kernel,
  sample,
  minima,
  zener,
  elasticParameters,
  moduli,
} from "./math.mjs?v=20261006-independent-stiffness";
import { pairCurve } from "./solver.mjs?v=20260924c";
import {
  cartesian,
  polar,
  mohr,
  sketch,
  strainShape,
  fmt,
} from "./plots.mjs?v=20261006-polar-magnitude";
import {
  element,
  value,
  stiffness,
  setStiffness,
  read,
  plateSettings,
} from "./state.mjs?v=20260924c";
import {
  clearMath,
  renderMath,
  mathematicalText,
  texNumber,
} from "./math-render.mjs?v=20260924c";
const set = (id, text) => {
  const target = element(id);
  clearMath(target);
  target.textContent = mathematicalText(text);
  renderMath(target);
};
const draw = (id, html) => {
  const target = element(id);
  clearMath(target);
  target.innerHTML = html;
  renderMath(target);
};
const degrees = (a) => ((a * 180) / Math.PI).toFixed(2) + "°";
const locations = (m) =>
  m.flat
    ? "all directions (flat curve)"
    : m.global.map((p) => degrees(p.angle)).join(", ");
// While following, θ sits on the first zero-extension root of the current t.
function followHabit() {
  if (!element("follow-habit").checked) return;
  const r = roots(value("t"));
  if (r.length) element("theta").value = ((r[0] * 180) / Math.PI).toFixed(4);
}
let worker = null,
  scanTimer = null,
  plateData = null,
  plateConfig = null;
function renderHabit(s) {
  const solutions = roots(s.t),
    p = projection(s.t, s.theta);
  element("t-slider").value = s.t;
  set(
    "tensor-readout",
    `ε⁰ = εη diag(1, t) = diag(${fmt(s.epsilon)}, ${fmt(s.epsilon * s.t)}). Principal strains: ${fmt(s.epsilon)}, ${fmt(s.epsilon * s.t)}. Selected εnn = ${fmt(s.epsilon * p)}.`,
  );
  set(
    "habit-result",
    solutions.length
      ? `Zero-extension line directions θ: ${solutions.map(degrees).join(", ")}. Interface normals are perpendicular. ${s.t === 0 ? "Limiting line: y = [01]." : ""}`
      : "No stress-free compatible habit line of this type.",
  );
  draw("strain-shape", strainShape(s.t));
  draw("mohr", mohr(s.t, s.theta, value("mohr-step")));
  const circle = mohrState(s.t, s.theta);
  const readout = element("mohr-readout");
  clearMath(readout);
  // Separate inline pieces so the readout can wrap on narrow screens.
  readout.textContent = String.raw`Centre \(c=(1+t)/2=${fmt(circle.centre)}\), radius \(R=|1-t|/2=${fmt(circle.radius)}\). At the selected angle: \(\epsilon^0_{nn}/\epsilon_\eta=${texNumber(fmt(circle.normal))}\), \(\epsilon^0_{nq}/\epsilon_\eta=${texNumber(fmt(circle.shear))}\).`;
  renderMath(readout);
  draw(
    "normal-strain",
    cartesian(
      [{ name: "εnn / εη", points: sample((a) => projection(s.t, a), 361) }],
      "Normal eigenstrain along n(θ)",
      { angle: s.theta, value: p },
    ),
  );
  draw("habit-sketch", sketch(s.theta));
  set(
    "habit-why",
    solutions.length
      ? `The principal strains ${fmt(s.epsilon)} and ${fmt(s.epsilon * s.t)} ${s.t < 0 ? "have opposite signs" : "include a zero"}. Their directional projection can vanish. Taking that direction as a line tangent permits the ideal 2-D compatibility construction. At the selected angle the normalized tangential strain is ${fmt(p)}; only a root is a candidate stress-free habit line. The orange normal is perpendicular to the green line.`
      : "Both principal strains have the same positive sign. Every directional projection is positive. The Mohr circle does not cross the zero-normal-strain axis; rotating the plate cannot supply this compatibility mechanism.",
  );
  element("find-habit").disabled = !solutions.length;
}
function syncPairStiffness(c) {
  const parameters = elasticParameters(c);
  const values = { "pair-c11": c.c11, "pair-c12": c.c12, "pair-c44": c.c44,
    "pair-mu": parameters.mu, "pair-nu": parameters.nu, "pair-az": parameters.z };
  for (const [id, number] of Object.entries(values)) {
    if (document.activeElement !== element(id)) element(id).value = Number(number.toPrecision(12));
  }
}
function renderKernels(s) {
  syncPairStiffness(s.c);
  const e = [s.epsilon, s.epsilon * s.t, 0],
    single = sample((a) => kernel(s.c, e, e, a)),
    m = minima(single),
    series = [{ name: "B(n)", points: single }];
  draw(
    "kernel-cart",
    cartesian(series, "Elastic energy kernel versus normal angle"),
  );
  draw("kernel-polar", polar(series, "B(n): modulation normal"));
  set(
    "kernel-result",
    `AZ = ${fmt(zener(s.c))}. Minimum B = ${fmt(m.lo)}. Normal directions: ${locations(m)}. ${m.flat ? "No preferred orientation from this kernel." : "Ideal plate tangents are 90° from these normals."}`,
  );
  set(
    "kernel-why",
    `C11 = ${fmt(s.c.c11)}, C12 = ${fmt(s.c.c12)}, C44 = ${fmt(s.c.c44)} set Q(n). Together with ε⁰ = diag(${fmt(e[0])}, ${fmt(e[1])}), they set σ⁰ and the relaxation term a·Q⁻¹a. The unrelaxed contraction ε⁰:C:ε⁰ is ${fmt(contract(e, stress(s.c, e)))}. At the minimum, relaxation removes ${fmt(contract(e, stress(s.c, e)) - m.lo)}, leaving B = ${fmt(m.lo)}. The preferred direction permits the greatest relaxation for this eigenstrain. ${m.flat ? "The cancellation is independent of direction." : "It favors a modulation normal, not an arbitrary real-space particle-separation direction."}`,
  );
  const bb = sample((a) => kernel(s.c, s.beta, s.beta, a)),
    gg = sample((a) => kernel(s.c, s.gamma, s.gamma, a)),
    bg = sample((a) => kernel(s.c, s.beta, s.gamma, a));
  const pairSeries = [
    { name: "Bββ", points: bb },
    { name: "Bγγ", points: gg },
    { name: "Bβγ", points: bg },
  ];
  draw(
    "pair-kernels-cart",
    cartesian(pairSeries, "Self and cross elastic energy kernels"),
  );
  draw("pair-kernels-polar", polar(pairSeries, "Kernel magnitudes: |Bpq(n)|", true));
  set(
    "pair-kernels-result",
    pairSeries
      .map(
        (series) =>
          `${series.name}: min ${fmt(minima(series.points).lo)} at ${locations(minima(series.points))}`,
      )
      .join(" | "),
  );
  set("pair-current-moduli", `Current stiffness: C11 = ${fmt(s.c.c11)}, C12 = ${fmt(s.c.c12)}, C44 = ${fmt(s.c.c44)}. Zener anisotropy ratio AZ = ${fmt(zener(s.c))}. ${Math.abs(zener(s.c)-1)<1e-10 ? "The moduli are isotropic. Dilatational kernels are constant with direction, so their polar magnitudes are circles." : "The moduli are anisotropic; dilatational kernels can vary with direction."}`);
  sandeepCheck(s);
  set(
    "pair-kernels-why",
    `All three curves use the same homogeneous C and Q⁻¹, but separate eigenstrain pairs. Self terms are quadratic; the cross term is bilinear. β = (${fmt(s.beta[0])}, ${fmt(s.beta[1])}), γ = (${fmt(s.gamma[0])}, ${fmt(s.gamma[1])}). Reversing every component of γ reverses Bβγ without changing Bγγ. ${Math.abs(zener(s.c)-1)<1e-10 && s.beta[0]===s.beta[1] && s.gamma[0]===s.gamma[1] ? "Homogeneous isotropic moduli and dilatational misfits: these kernels are direction independent, as required by the Bitter–Crum limit. Changing a misfit changes the coefficient, not the flat curve shape." : "Directional dependence can come from anisotropic stiffness or non-dilatational eigenstrain. Compare with the isotropic dilatational case."} The curve minima above are calculated from these contractions.`,
  );
}
// Reference case: Sandeep Sugathan, IIT Hyderabad thesis (2019), Chapter 5,
// alloy X2, Fig. 5.18: G = 2000, nu = 1/3, AZ = 3, misfits +0.01 and -0.01.
function sandeepCheck(s) {
  const box = element("sandeep-check"),
    ref = moduli(2000, 1 / 3, 3),
    near = (a, b) => Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(b)),
    isCase =
      near(s.c.c11, ref.c11) &&
      near(s.c.c12, ref.c12) &&
      near(s.c.c44, ref.c44) &&
      near(s.beta[0], 0.01) &&
      near(s.beta[1], 0.01) &&
      near(s.gamma[0], -0.01) &&
      near(s.gamma[1], -0.01);
  box.hidden = !isCase;
  if (!isCase) return;
  const rows = [
    ["B_{\\beta\\beta}", s.beta, s.beta, 0.342857, 0.8],
    ["B_{\\gamma\\gamma}", s.gamma, s.gamma, 0.342857, 0.8],
    ["B_{\\beta\\gamma}", s.beta, s.gamma, -0.342857, -0.8],
  ];
  let html =
    '<p class="sd-title"><strong>Reference check: Sandeep Sugathan’s thesis, alloy X<sub>2</sub> (Chapter 5, Fig. 5.18).</strong> ' +
    "G = 2000, ν = 1/3 and A<sub>Z</sub> = 3 give C11 = 7000, C12 = 5000, C44 = 3000 (Eqs. 3.27–3.29); β and γ carry dilatational misfits +0.01 and −0.01 (Tables 5.1–5.2).</p>" +
    '<div class="sd-scroll"><table class="lab-table"><thead><tr><th rowspan="2">kernel</th><th colspan="2">along ⟨10⟩</th><th colspan="2">along ⟨11⟩</th><th rowspan="2"></th></tr><tr><th>this page</th><th>thesis</th><th>this page</th><th>thesis</th></tr></thead><tbody>';
  for (const [name, p, q, t10, t11] of rows) {
    const v10 = kernel(s.c, p, q, 0),
      v11 = kernel(s.c, p, q, Math.PI / 4),
      ok = Math.abs(v10 - t10) < 5e-6 && Math.abs(v11 - t11) < 5e-6;
    html += `<tr><td>\\(${name}\\)</td><td>${v10.toFixed(6)}</td><td>${t10.toFixed(6)}</td><td>${v11.toFixed(6)}</td><td>${t11.toFixed(6)}</td><td>${ok ? "✓ agrees" : "differs"}</td></tr>`;
  }
  html +=
    "</tbody></table></div>" +
    '<p class="sd-note">Why these shapes: with A<sub>Z</sub> = 3 the crystal is elastically soft along ⟨10⟩, so each self term is lowest along ⟨10⟩ and highest along ⟨11⟩. The two misfits are equal and opposite, so B<sub>ββ</sub> and B<sub>γγ</sub> are identical (the dashed curve lies on the solid one) and B<sub>βγ</sub> is their mirror image. The most negative cross term is along ⟨11⟩, which favours β–γ neighbours along the diagonals; the pair calculation below shows the same preference.</p>';
  draw("sandeep-check", html);
}
function renderPair(s) {
  const type = element("pair-type").value,
    p = type === "gg" ? s.gamma : s.beta,
    q = type === "bb" ? s.beta : s.gamma,
    points = pairCurve(s.c, p, q, { distance: value("separation") }),
    m = minima(points),
    a = radians(value("pair-angle")),
    nearest = points[Math.round(value("pair-angle")) % 180];
  draw(
    "pair-energy",
    cartesian(
      [{ name: "Eint", points }],
      "Pair energy versus separation angle",
      { angle: a, value: nearest.value },
    ),
  );
  draw(
    "pair-sketch",
    sketch(a, {
      pair: true,
      phase: type === "bb" ? "ββ" : type === "gg" ? "γγ" : "βγ",
      distance: value("separation"),
    }),
  );
  set(
    "pair-result",
    `${type === "bg" ? "β–γ" : type === "bb" ? "β–β" : "γ–γ"} pair: minimum interaction energy ${fmt(m.lo)} at ${locations(m)}. At nearest 1° sample to selected angle: ${fmt(nearest.value)}. Energy is per box area.`,
  );
  const axis = points[0].value, diagonal = points[45].value;
  draw("pair-direction-comparison", `<table class="lab-table"><thead><tr><th>Particle separation</th><th>Signed interaction energy / box area</th></tr></thead><tbody><tr><td>[10] · 0°</td><td>${fmt(axis)}</td></tr><tr><td>[11] · 45°</td><td>${fmt(diagonal)}</td></tr></tbody></table><p>${m.flat ? "No resolved directional preference." : diagonal < axis ? "[11] has lower interaction energy than [10]." : "[10] has lower interaction energy than [11]."} Compare signed values: a more negative value is lower energy. The self kernels and the magnitude polar plot above are different quantities.</p>`);
  set(
    "pair-why",
    `The cross kernel weights every mode of the particle profile. Separation ${value("separation")} enters through cos(k·R), so the summed interaction has minima at ${locations(m)}. This includes periodic copies and the clamped zero mode. Negative interaction energy lowers the total relative to the two separate profiles in the same box; it does not mean the full elastic energy is negative.`,
  );
}
function render() {
  try {
    const s = read();
    renderHabit(s);
    renderKernels(s);
    renderPair(s);
    set("lab-error", "");
  } catch (error) {
    set(
      "lab-error",
      error.message + " Plots retain the last valid calculation.",
    );
  }
}
function plateSketch() {
  const angle = radians(value("plate-angle"));
  draw("plate-sketch", sketch(angle));
  if (plateData) {
    const index =
      Math.round((value("plate-angle") / 180) * plateData.length) %
      plateData.length;
    draw(
      "plate-cart",
      cartesian(
        [{ name: "Eel", points: plateData }],
        "Finite plate energy versus tangent angle",
        { angle, value: plateData[index].value },
      ),
    );
  }
}
function stop() {
  if (worker) worker.terminate();
  worker = null;
  clearTimeout(scanTimer);
  element("stop-plate").disabled = true;
}
function scan() {
  stop();
  try {
    read();
    const config = plateSettings();
    plateConfig = config;
    plateData = null;
    element("download-plate").disabled = true;
    set("plate-result", "Calculating with current parameters.");
    set("plate-progress", "Starting mechanical-equilibrium solves…");
    draw("plate-cart", "");
    draw("plate-polar", "");
    plateSketch();
    worker = new Worker(new URL("./worker.mjs?v=20260924c", import.meta.url), {
      type: "module",
    });
    element("stop-plate").disabled = false;
    worker.onmessage = ({ data }) => {
      if (data.error) {
        set("plate-progress", data.error);
        stop();
        return;
      }
      if (data.progress) {
        set(
          "plate-progress",
          `Solving ${config.n} × ${config.n} grid: ${(data.progress * 100).toFixed(0)}%`,
        );
        return;
      }
      plateData = data.points;
      const m = minima(plateData);
      draw(
        "plate-cart",
        cartesian(
          [{ name: "Eel", points: plateData }],
          "Finite plate energy versus tangent angle",
        ),
      );
      draw(
        "plate-polar",
        polar(
          [{ name: "Eel", points: plateData }],
          "Finite plate energy: tangent angle",
        ),
      );
      set(
        "plate-result",
        `Sampled global minimum ${fmt(m.lo)} at ${locations(m)}. Local minima: ${m.flat ? "all angles" : m.local.map((p) => degrees(p.angle)).join(", ")}. Grid ${config.n}²; angle step ${180 / config.count}°. ${Math.abs(zener(config.cm) - 1) < 1e-10 && Math.abs(zener(config.cp) - 1) < 1e-10 && config.eigen[0] === config.eigen[1] && config.eigen[2] === 0 ? "Both phases are isotropic with dilatational misfit: any angular differences here arise from the periodic cell and discretization, not a crystallographic direction in an infinite medium." : ""} Energy spread ${((100 * (m.hi - m.lo)) / Math.max(Math.abs(m.hi), 1e-30)).toPrecision(3)}%. ${m.hi - m.lo < 0.005 * Math.max(Math.abs(m.hi), 1e-30) ? "Weak or unresolved orientation preference. Refine the grid before interpreting these minima." : ""}`,
      );
      set(
        "plate-progress",
        `Complete. Maximum relative residual ${data.worst.toExponential(2)}; maximum ${data.maxIterations} PCG iterations.${data.referenceError !== null ? " Homogeneous Fourier check: relative error " + data.referenceError.toExponential(2) + "." : ""}`,
      );
      set(
        "plate-why",
        `For the ${config.phase} plate, C varies from matrix (${Object.values(config.cm).map(fmt).join(", ")}) to plate (${Object.values(config.cp).map(fmt).join(", ")}); entries are C11, C12, C44. The fixed eigenstrain is (${config.eigen.map(fmt).join(", ")}). Each orientation changes which parts of this mismatch can relax through the spatially varying stiffness. Mechanical equilibrium is solved anew at every angle. The lowest sampled elastic penalty is at ${locations(m)}. At a minimum, the energy before displacement relaxation is ${fmt(plateData.reduce((best, p) => (p.value < best.value ? p : best)).unrelaxedEnergy)}; equilibrium reduces it to ${fmt(m.lo)}. The released energy is ${fmt(plateData.reduce((best, p) => (p.value < best.value ? p : best)).unrelaxedEnergy - m.lo)}. This finite plate need not choose the zero-extension angle of an infinite plate. Compare finer grids and angular steps before interpreting small differences.`,
      );
      element("download-plate").disabled = false;
      stop();
    };
    worker.onerror = (e) => {
      set("plate-progress", "Solver error: " + e.message);
      stop();
    };
    worker.postMessage(config);
  } catch (error) {
    set("plate-progress", error.message);
  }
}
function queueScan() {
  stop();
  set("plate-result", "Parameters changed; previous results cleared.");
  plateData = null;
  draw("plate-cart", "");
  draw("plate-polar", "");
  element("download-plate").disabled = true;
  scanTimer = setTimeout(scan, 450);
}
element("t-slider").addEventListener("input", () => {
  element("t").value = value("t-slider");
  followHabit();
  try {
    const s = read();
    renderHabit(s);
    renderKernels(s);
    set("lab-error", "");
  } catch (error) {
    set("lab-error", error.message + " Plots retain the last valid calculation.");
  }
});
for (const id of ["t", "epsilon", "theta"])
  element(id).addEventListener("input", () => {
    try {
      if (id === "theta") element("follow-habit").checked = false;
      if (id === "t") followHabit();
      const s = read();
      renderHabit(s);
      renderKernels(s);
      set("lab-error", "");
    } catch (error) {
      set(
        "lab-error",
        error.message + " Plots retain the last valid calculation.",
      );
    }
  });
// I link the local stiffness inputs to the shared constants and both plots.
for (const id of ["pair-c11", "pair-c12", "pair-c44", "pair-mu", "pair-nu", "pair-az"]) {
  element(id).addEventListener("input", () => {
    try {
      if (element(id).value.trim() === "" || !Number.isFinite(value(id)))
        throw Error("Enter a finite elastic parameter.");
      let c;
      if (["pair-c11", "pair-c12", "pair-c44"].includes(id)) {
        c = { c11: value("pair-c11"), c12: value("pair-c12"), c44: value("pair-c44") };
        elasticParameters(c);
      } else {
        const mu = value("pair-mu"), nu = value("pair-nu"), z = value("pair-az");
        if (!(mu > 0 && nu > -1 && nu < 0.5 && z > 0))
          throw Error("Require μ > 0, −1 < ν < 1/2 and AZ > 0.");
        c = moduli(mu, nu, z);
      }
      setStiffness("c", c);
      syncPairStiffness(c);
      render();
    } catch (error) {
      set("lab-error", error.message + " Plots retain the last valid calculation.");
    }
  });
}
// Update the kernel controls while the student edits them, not only on blur.
for (const id of ["beta", "gamma", "tbeta", "tgamma", "cc11", "cc12", "cc44"])
  element(id).addEventListener("input", render);
// Module II (ids es-*) has its own controller.
for (const input of document.querySelectorAll(
  "#elastic-lab input:not([id^=es-]),#elastic-lab select:not([id^=es-])",
))
  input.addEventListener("change", () => {
    if (input.id === "follow-habit") {
      followHabit();
      render();
      return;
    }
    if (input.id === "mohr-step") {
      renderHabit(read());
      return;
    }
    if (input.id === "plate-angle") {
      plateSketch();
      return;
    }
    render();
    if (
      /^[mbg]c(11|12|44)$/.test(input.id) ||
      [
        "beta",
        "gamma",
        "tbeta",
        "tgamma",
        "plate-phase",
        "grid-size",
        "angle-count",
      ].includes(input.id)
    )
      queueScan();
  });
for (const button of document.querySelectorAll("[data-preset]"))
  button.addEventListener("click", () => {
    try {
      const preset = button.dataset.preset;
      if (["minus", "zero", "positive"].includes(preset)) {
        element("t").value = { minus: -1, zero: 0, positive: 0.5 }[preset];
        followHabit();
      }
      if (preset === "isotropic") {
        const c = stiffness("c");
        c.c44 = (c.c11 - c.c12) / 2;
        setStiffness("c", c);
      }
      if (preset === "anisotropic")
        setStiffness("c", { c11: 3, c12: 1, c44: 3 });
      if (["opposite", "sandeep"].includes(preset)) {
        element("beta").value = 0.01;
        element("gamma").value = -0.01;
        element("tbeta").value = 1;
        element("tgamma").value = 1;
        if (preset === "sandeep") {
          setStiffness("c", moduli(2000, 1 / 3, 3));
          element("pair-type").value = "bg";
          element("pair-angle").value = 45;
        }
        queueScan();
      }
      if (["soft", "hard", "homogeneous"].includes(preset)) {
        const c = stiffness("m"),
          ratio = { soft: 0.5, hard: 2, homogeneous: 1 }[preset];
        setStiffness(
          element("plate-phase").value === "beta" ? "b" : "g",
          Object.fromEntries(
            Object.entries(c).map(([key, v]) => [key, v * ratio]),
          ),
        );
        queueScan();
      }
      render();
    } catch (error) {
      set("lab-error", error.message);
    }
  });
element("find-habit").addEventListener("click", () => {
  const target = roots(value("t"))[0];
  if (target === undefined) return;
  element("follow-habit").checked = false;
  const start = value("theta"),
    end = (target * 180) / Math.PI,
    time = performance.now(),
    duration = matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 650;
  function frame(now) {
    const f = duration ? Math.min(1, (now - time) / duration) : 1;
    element("theta").value = (start + (end - start) * f).toFixed(4);
    if (f >= 1) element("follow-habit").checked = true;
    renderHabit(read());
    if (f < 1) requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
});
element("scan-plate").addEventListener("click", scan);
element("stop-plate").addEventListener("click", () => {
  stop();
  set("plate-progress", "Stopped. Change parameters or calculate again.");
});
element("download-plate").addEventListener("click", () => {
  const blob = new Blob(
      [
        JSON.stringify(
          {
            parameters: plateConfig,
            boundary: "periodic, mean total strain zero",
            points: plateData,
          },
          null,
          2,
        ),
      ],
      { type: "application/json" },
    ),
    url = URL.createObjectURL(blob),
    a = document.createElement("a");
  a.href = url;
  a.download = "elastic-plate-results.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
fetch("/files/elastic-lab/validation-results.json")
  .then((r) => r.json())
  .then((report) =>
    set(
      "validation-summary",
      `${report.tests.length} validation groups passed. These cover the appendix kernel and driving force, Mohr-circle invariants, Eshelby’s ellipse against Mura’s closed form and its interface jump conditions, Fourier scaling, CICP spectral iteration versus PCG, Sandeep’s reference, homogeneous recovery and resolution convergence. The full report includes numerical errors.`,
    ),
  )
  .catch(() => {});
followHabit();
render();
plateSketch();
scan();

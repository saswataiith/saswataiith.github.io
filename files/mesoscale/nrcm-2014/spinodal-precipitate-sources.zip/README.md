# NRCM 2014 phase-field workshop codes

Three C examples from my 2014 NRCM phase-field workshop:

- `PFWorkshop2014/Spinodal`: Cahn-Hilliard spinodal decomposition in 2D.
- `PFWorkshop2014/PptCodes1D`: precipitate growth in 1D (conserved composition and a nonconserved structural field).
- `PFWorkshop2014/PptCodes2D`: the same precipitate model in 2D.

Page with the equations: https://saswataiith.github.io/resources/nrcm-phase-field/

Terms of use: see `LICENSING.md` and `CODE-USE-TERMS.txt`.

## Requirements

- A C compiler with OpenMP headers (GCC on Linux; on macOS, Homebrew `gcc`).
- FFTW 3. Ubuntu or Debian: `sudo apt install build-essential libfftw3-dev`. macOS: `brew install gcc fftw`.

## Build and run

```bash
cd PFWorkshop2014/Spinodal      # or PptCodes1D, PptCodes2D
make
./spinodal.out                  # ./pptg.out in PptCodes1D and PptCodes2D
```

Each program reads `bin1ary`, which names the input file (`InputParams`) and the file that records the parameters used (`OutParams`). Keep it in the folder. Edit `InputParams` to change grid size, time step, number of steps and model coefficients. All quantities are nondimensional.

Spinodal writes `conf.NNNNNN` snapshots as raw binary: `2*nx*ny` little-endian doubles (real and imaginary parts, interleaved), with the composition in the real part. In NumPy:

```python
import numpy as np
c = np.fromfile("conf.002000", dtype=np.float64)[0::2].reshape(nx, ny)
```

On macOS with Homebrew, build with `make CC=gcc-14 CFLAGS="-std=c99 -O3 -fopenmp -fcommon -I/opt/homebrew/include" LDFLAGS=-L/opt/homebrew/lib` (use your installed GCC version number).

## What changed in 2026

The C sources are unchanged from 2014. Only the Makefiles were updated:

- `-fcommon` added, because `binary.h` defines global variables and GCC 10 and later reject that by default.
- `PptCodes1D` now compiles `main.c` alone, because `main.c` #includes the other `.c` files.
- A Makefile was added for `Spinodal`, which had none.
- `-lfftw3_omp` removed: the codes do not use threaded FFTW.

Checked in October 2026 with GCC on Ubuntu and FFTW 3.3.10: all three build without warnings and run. In Spinodal, the mean composition stays at 0.5 to eight decimal places while the field separates towards 0 and 1.

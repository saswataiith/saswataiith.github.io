#include"binary.h"

void Init_Conf()
{
FILE *fp;
char fn[100];
 for (int j = 0; j < ny; j++) {
  for (int i = 0; i < nx; i++) {
       float ppt_radius = ceil(ppt_size/2.0);
       float x = (float) (i - nx_half);
       float y = (float) (j - ny_half);
       if ((x*x + y*y) <= (ppt_radius * ppt_radius)) {
        comp[j + i * ny][Re] = 1.0;
        eta[j + i * ny][Re] = 1.0;
   } else {
      comp[j + i * ny][Re] = supersaturation;
      eta[j + i * ny][Re] = 0.0;
   }
    comp[j + i * ny][Im] = 0.0;
    eta[j + i * ny][Im] = 0.0;
   }
  }
          
 for (int j = 0; j < ny; j++) {
  for (int i = 0; i < nx; i++) {
   dfdc[j + i * ny][Re] = comp[j + i * ny][Re];
   dfdc[j + i * ny][Im] = comp[j + i * ny][Im];
   dfdeta[j + i * ny][Re] = eta[j + i * ny][Re];
   dfdeta[j + i * ny][Im] = eta[j + i * ny][Im];
  }
 }
sprintf(fn, "profile.in");  
 if (!(fp = fopen (fn, "w"))) {
  printf ("File:%s could not be opened \n", fn);
  exit (1);
 }
 for (int j = 0; j < ny; j++) {
  for (int i = 0; i < nx; i++) {
   fprintf(fp,"%d\t%d\t%lf\t%lf\n",j,i,comp[j+i*ny][Re],eta[j+i*ny][Re]);
  }
 fprintf(fp,"\n");
 }
fclose(fp); 
}

void Read_Restart()
{
 FILE *fpread;
 char fr[100];

 sprintf (fr,"conf.%06d", initcount);
 fpread = fopen (fr, "r");
 if(fread (&comp[0][0], sizeof(double), 2 * nx * ny, fpread));
 if(fread (&eta[0][0], sizeof(double), 2 * nx * ny, fpread));
 fclose (fpread);
 
 for (int j = 0; j < ny; j++) {
  for (int i = 0; i < nx; i++) {
   dfdc[j + i * ny][Re] = comp[j + i * ny][Re];
   dfdc[j + i * ny][Im] = comp[j + i * ny][Im];
   dfdeta[j + i * ny][Re] = eta[j + i * ny][Re];
   dfdeta[j + i * ny][Im] = eta[j + i * ny][Im];
  }
 }
}

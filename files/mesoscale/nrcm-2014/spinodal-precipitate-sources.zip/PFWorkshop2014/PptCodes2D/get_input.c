#include"binary.h"
void Get_Input_Parameters (char *fnin, char *fnout)
{
 FILE *fpin, *fpcout;
 char param[100], fn[100];

 if (!(fpcout = fopen (fnout, "w"))) {
  printf ("File:%s could not be opened \n", fnout);
  exit (1);
 }
 fprintf (fpcout, "The name of this file is : %s \n", fnout);
 fprintf (fpcout, "Input is from            : %s \n", fnin);

 if (!(fpin = fopen (fnin, "r"))) {
  printf ("File: %s could not be opened \n", fnin);
  exit (1);
 }

 if(fscanf (fpin, "%s%d", param,&nx));
 if(fscanf (fpin, "%s%d", param,&ny));
 if(fscanf (fpin, "%s%lf",param,&dx));
 if(fscanf (fpin, "%s%lf",param,&dy));
 if(fscanf (fpin, "%s%le",param,&dt));
 if(fscanf (fpin, "%s%d", param,&num_steps));
 if(fscanf (fpin, "%s%lf%s%lf%s%lf", param, &A, param, &B, param, &P));
 if(fscanf (fpin, "%s%lf",param,&supersaturation));
 if(fscanf (fpin, "%s%lf",param,&ppt_size));
 if(fscanf (fpin, "%s%lf%s%lf", param, &kappa_c, param, &kappa_eta));
 if(fscanf (fpin, "%s%lf%s%lf", param, &mobility, param, &relax_coeff));
 if(fscanf (fpin, "%s%d", param,&initflag));
 if(fscanf (fpin, "%s%d", param,&initcount));
 if(fscanf (fpin, "%s%d", param,&fftw_flag));
 fclose (fpin);
 
 printf("nx=%d\n",nx);
 printf("ny=%d\n",ny);
 printf("dx=%lf\n",dx);
 printf("dy=%lf\n",dy);
 printf("dt=%le\n",dt); 
 printf("Simulation steps = %d\n", num_steps);
 printf("Bulk free energy coefficients A=%lf\t B=%lf\t P=%lf\n",A,B,P);
 printf("Supersaturation = %lf\n", supersaturation);
 printf("ppt_size = %lf\n", ppt_size);
 printf("Kappa_c = %lf\t Kappa_eta = %lf\n", kappa_c, kappa_eta);
 printf("Mobility = %lf\t Relaxation Coefficient = %lf\n", mobility, relax_coeff);
 printf("Initflag = %d\n", initflag);
 printf("File read from steps = %d\n", initcount);
 if(kappa_c <= 1.0e-08 || kappa_eta <= 1.0e-08) {
  printf("Warning: too small or negative values for gradient energy coefficients\n");
  printf("Using default values\n");
  kappa_c = 1.0;
  kappa_eta = 1.0;
  printf("Kappa_c (default) = %lf\t Kappa_eta (default) = %lf\n", kappa_c, kappa_eta);
 }
 if(mobility <= 1.0e-08 || relax_coeff <= 1.0e-08) {
  printf("Warning: too small or negative values for kinetic coefficients\n");
  printf("Using default values\n");
  mobility = 1.0;
  relax_coeff = 1.0;
  printf("Mobility (default) = %lf\t Relaxation Coefficient (default) = %lf\n", mobility, relax_coeff);
 }
 if(initflag == 0) {
  printf("Configuration initialized by me\n");
  initcount = 0;
 } else {
  sprintf(fn,"conf.%06d", initcount);     
  printf("Configuration read from file %s\n",fn);
 }
 printf("FFTW_FLAG = %d\n",fftw_flag);

 fprintf (fpcout, "nx %d\n", nx);
 fprintf (fpcout, "ny %d\n", ny);
 fprintf (fpcout, "dx %lf\n",dx);
 fprintf (fpcout, "dy %lf\n",dy);
 fprintf (fpcout, "dt %lf\n",dt);
 fprintf (fpcout, "num_steps %d\n", num_steps);
 fprintf (fpcout, "A   %3.2f   B   %3.2f   P   %3.2f\n", A, B, P);
 fprintf (fpcout, "Supersaturation  %lf\n", supersaturation);
 fprintf (fpcout, "Ppt_size %lf\n", ppt_size);
 fprintf (fpcout, "kappa_c %lf\t kappa_eta %lf\n", kappa_c, kappa_eta);
 fprintf (fpcout, "mobility %lf\t relax_coeff %lf\n", mobility, relax_coeff);
 fprintf (fpcout, "initflag %d\n", initflag);
 fprintf (fpcout, "initcount %d\n", initcount);
 fprintf (fpcout, "fftw_flag %d\n", fftw_flag);
 fclose(fpcout);
}

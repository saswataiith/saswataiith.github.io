#include"binary.h"

void Init_Conf()
{
int i;
FILE *fp;
char fn[100];
 if (calc_interface_energy == 1){
  for (i = 0; i < nx; i++) {
   if (i < nx_half) {
     comp[i][Re] = 1.0;
     eta[i][Re] = 1.0;
    } else {
     comp[i][Re] = 0.0;
     eta[i][Re] = 0.0;
    }   
   comp[i][Im] = 0.0;
   eta[i][Im] = 0.0;
   }
  } else {
    for ( i = 0; i < nx; i++) {
     double ppt_radius = ceil(ppt_size/2.0);
     double x = (double) (i - nx_half);
      if (x*x <= ppt_radius * ppt_radius) {
        comp[i][Re] = 1.0;
       eta[i][Re] = 1.0;
   } else {
      comp[i][Re] = supersaturation;
     eta[i][Re] = 0.0;
    }
    comp[i][Im] = 0.0;
    eta[i][Im] = 0.0;
   }
  }
          
  for (i = 0; i < nx; i++) {
   dfdc[i][Re] = comp[i][Re];
   dfdc[i][Im] = comp[i][Im];
   dfdeta[i][Re] = eta[i][Re];
   dfdeta[i][Im] = eta[i][Im];
  }
 sprintf(fn, "profile.in");  
 if (!(fp = fopen (fn, "w"))) {
  printf ("File:%s could not be opened \n", fn);
  exit (1);
 }
  for (i = 0; i < nx; i++) {
  fprintf(fp,"%d\t%lf\t%lf\n",i,comp[i][Re],eta[i][Re]);
 }
fclose(fp); 
}

void Read_Restart()
{
 FILE *fpread;
 char fr[100];
 int i;

 sprintf (fr,"conf.%06d", initcount);
 fpread = fopen (fr, "r");
 if(fread (&comp[0], sizeof(double), 2 * nx, fpread));
 if(fread (&eta[0], sizeof(double), 2 * nx, fpread));
 fclose (fpread);
 
  for (i = 0; i < nx; i++) {
   dfdc[i][Re] = comp[i][Re];
   dfdc[i][Im] = comp[i][Im];
   dfdeta[i][Re] = eta[i][Re];
   dfdeta[i][Im] = eta[i][Im];
  }
}

#include"binary.h"
void Evolve()
{
void Output_Conf (int steps);

int loop_condition, count;

double dkx, kx, kpow2, kpow4;

double rc, fp, rc_new, reta_new;

double reta, fpeta;
 
double total;
 
double *tempreal;
 
double lhs, rhs, lhse, rhse;

double err, maxerror;

tempreal = (double*) malloc(sizeof(double) * nx);

dkx = 2.0 * PI / ((double) nx * dx);
 
  for (int i = 0; i < nx; i++)
   tempreal[i] = comp[i][Re];
 
loop_condition = 1;

//Take composition and eta to Fourier space
fftw_execute_dft (p_up, comp, comp);
fftw_execute_dft (p_up, eta, eta);


alloycomp = comp[0][Re] * one_by_nx;

 for (count = 0; count <= num_steps; count++) {
  
  if (((count % 2000)==0) || (count == num_steps) || (loop_condition == 0)) {
   printf ("total_time=%lf\n", sim_time);
   printf ("writing configuration to file!\n");
   Output_Conf(count);
  }
  
  if (count > num_steps || loop_condition == 0)
  break;

//Here dfdc and dfdeta are in real space. Note that dfdc and dfdeta stores comp 
// and eta in real space. 
  for (int i = 0; i < nx; i++) {
   float interp_eta, interp_prime;
   float ctemp, etemp;
   ctemp = dfdc[i][Re];
   etemp = dfdeta[i][Re];
   interp_eta = etemp * etemp * (3.0 - 2.0 * etemp);
   interp_prime = 6.0 * etemp - 6.0 * etemp * etemp;  

   dfdc[i][Re] = 2.0 * A * ctemp * (1.0 - interp_eta) 
             - 2.0 * B * (1.0 - ctemp) * interp_eta;  

   dfdeta[i][Re] = -1.0 * A * ctemp * ctemp * interp_prime
              + B * (1.0  - ctemp) * (1.0 - ctemp) * interp_prime
          + 2.0 * P * etemp * (1.0 - etemp) * (1.0 - 2.0*etemp);

  dfdc[i][Im] = 0.0;
  dfdeta[i][Im] = 0.0;
  }

 // Take dfdc and dfdeta to Fourier space 
 fftw_execute_dft (p_up, dfdc, dfdc);
 fftw_execute_dft (p_up, dfdeta, dfdeta);

  for (int i = 0; i < nx; i++) {
   if (i <= nx_half)
    kx = (double) i * dkx;
   else
    kx = (double) (i - nx) * dkx;
    
  kpow2 = kx*kx;
  kpow4 = kpow2 * kpow2;

  lhs = 1.0 + 2.0 * mobility * kappa_c * kpow4 * dt;
    
  rc = comp[i][Re];
  fp = dfdc[i][Re];
  rhs = rc - mobility * kpow2 * dt * fp;
  rc_new = rhs / lhs;
  comp[i][Re] = rc_new;
  dfdc[i][Re] = comp[i][Re];

  rc = comp[i][Im];
  fp = dfdc[i][Im];
  rhs = rc - mobility * kpow2 * dt * fp;
  rc_new = rhs / lhs;
  comp[i][Im] = rc_new;
  dfdc[i][Im] = comp[i][Im];
 
 
  lhse = 1.0 + 2.0 * relax_coeff * kappa_eta * kpow2 * dt;
 
  reta = eta[i][Re];
  fpeta = dfdeta[i][Re];
  rhse = reta - relax_coeff * dt * fpeta;
  reta_new = rhse/lhse;
  eta[i][Re] = reta_new;
  dfdeta[i][Re] = eta[i][Re];

  reta = eta[i][Im];
  fpeta = dfdeta[i][Im];
  rhse = reta - relax_coeff * dt * fpeta;
  reta_new = rhse/lhse;
  eta[i][Im] = reta_new;
  dfdeta[i][Im] = eta[i][Im];
  }

/* Check for conservation of mass */
  total = dfdc[0][Re] * one_by_nx;
  err = fabs (total - alloycomp);
  if (err > COMPERR) {
   printf ("ELEMENTS ARE NOT CONSERVED,SORRY!!!!\n");
   printf ("error=%lf\n", err);
   exit (0);
  }

//Keep comp and eta in fourier space and take dfdc and dfdeta to real space which store// comp and eta in real space (comp(Re) = dfdc(Re), eta(Re) = dfdeta(Real))
  fftw_execute_dft (p_dn, dfdc, dfdc);
  fftw_execute_dft (p_dn, dfdeta, dfdeta);

   for (int i = 0; i < nx; i++) {
    dfdc[i][Re] *= one_by_nx;
    dfdc[i][Im] *= one_by_nx;
    dfdeta[i][Re] *= one_by_nx; 
    dfdeta[i][Im] *= one_by_nx; 
   }


/* Check for bounds */
    for (int i = 0; i < nx; i++) {
     if (dfdc[i][Re] < -0.2
        || dfdc[i][Re] > 1.2) {
     printf ("Compositions out of bounds. Exiting\n");
     exit (0);
    }
   }

  
/* Check for convergence */
  maxerror = 0.0;
    for (int i = 0; i < nx; i++) {
      err = fabs (tempreal[i] - dfdc[i][Re]);
      if (err > maxerror)
     maxerror = err;
   }
  if (maxerror <= Tolerance) {
   printf ("maxerror=%lf\tnumbersteps=%d\n", maxerror, count);
   loop_condition = 0;
  }
  sim_time = sim_time + dt;
//  printf("time=%lf\n", sim_time);
   for (int i = 0; i < nx; i++) {
    tempreal[i] = dfdc[i][Re];
   }
  }
}
